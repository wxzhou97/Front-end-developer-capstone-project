import React from "react";

function Footer() {
    return ( <
        footer className = "footer" >
        <
        p > & copy; 2024 Little Lemon < /p> <
        p > Contact us: info @littlelemon.com < /p> < /
        footer > ;)

}

export default Footer;