import React from "react";

function Specials() {
    return ( <
        section className = "specials" >
        <
        h2 > Our Specials < /h2> {/ * Placeholder content * /}{" "} <
        div className = "special-item" > Special Item 1 < /div>{" "} <
        div className = "special-item" > Special Item 2 < /div>{" "} <
        div className = "special-item" > Special Item 3 < /div>{" "} <
        /section>
    );
}

export default Specials;