import React from "react";

function ConfirmedBooking() {
    return ( <
        div >
        <
        h1 > Booking Confirmed < /h1>{" "} <
        p >
        Your booking has been confirmed.Thank you
        for choosing Little Lemon!
        <
        /p>{" "} <
        /div>
    );
}

export default ConfirmedBooking;